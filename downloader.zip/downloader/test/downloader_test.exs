defmodule DownloaderTest do
  use ExUnit.Case
  doctest Downloader

  test "returns error for missing file" do
    assert Downloader.install("/this/path/does/not/exist.tar.gz") == {:error, :file_not_found}
  end
end
