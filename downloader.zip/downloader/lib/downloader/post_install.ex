defmodule Downloader.PostInstall do
  @moduledoc """
  Обробляє пост-установочні завдання, такі як пошук та запуск скриптів установки.
  """

  alias Downloader.SystemUtils

  # Перевірка директорії на наявність скриптів установки
  def inspect_directory(dir_path) do
    # Список відомих скриптів/файлів установки
    installer_scripts = ["install.sh", "setup.py", "makefile", "readme.md", "install"]

    case File.ls(dir_path) do
      {:ok, files} ->
        # Перетворюємо всі імена файлів у нижній регістр для порівняння
        files_downcased = Enum.map(files, &String.downcase/1)

        # Шукаємо відомі скрипти установки
        found_scripts = Enum.filter(files_downcased, fn file ->
          Enum.member?(installer_scripts, file)
        end)

        if Enum.any?(found_scripts) do
          IO.puts "Знайдено потенційні скрипти/файли установки:"
          Enum.each(found_scripts, fn script ->
            IO.puts "- #{script}"
            cond do
              script == "install.sh" ->
                IO.puts "  Можливо, ви захочете запустити: bash #{Path.join(dir_path, "install.sh")}"
              script == "makefile" ->
                IO.puts "  Можливо, ви захочете запустити: make && sudo make install"
              true ->
                :ok
            end
          end)
        else
          IO.puts "Загальні скрипти установки не знайдені в розпакованій директорії."
          IO.puts "Можливо, вам доведеться вручну перевірити вміст."
        end

      {:error, reason} ->
        IO.puts "Помилка перегляду директорії #{dir_path}: #{inspect(reason)}"
    end
  end

  # ----- Автоматизовані дії після розпакування -----
  def automate_post_unpack(base_dir) do
    # Рекурсивно шукаємо файли до глибини 3
    files = recurse_files(base_dir, 5) ##############################################################################

    # 1) Шукаємо та запускаємо install.sh
    case Enum.find(files, &String.ends_with?(&1, "/install.sh")) do
      nil -> :ok
      script ->
        _ = File.chmod(script, 0o755)  # Робимо виконуваним
        IO.puts("Запуск скрипта установки: #{script}")
        _ = SystemUtils.run_cmd("bash", [script])
    end

    # 2) Шукаємо та запускаємо setup.py
    case Enum.find(files, &String.ends_with?(&1, "/setup.py")) do
      nil -> :ok
      setup ->
        # Вибираємо аргументи залежно від того, чи ми root
        args = if SystemUtils.running_as_root?(), do: [setup, "install"], else: [setup, "install", "--user"]
        IO.puts("Запуск Python setup: #{Enum.join(["python3" | args], " ")}")
        _ = SystemUtils.run_cmd("python3", args)
    end

    # 3) Шукаємо та запускаємо Makefile
    case Enum.find(files, fn p -> String.ends_with?(String.downcase(p), "/makefile") end) do
      nil -> :ok
      makefile ->
        dir = Path.dirname(makefile)
        IO.puts("Запуск make в #{dir}")
        _ = SystemUtils.run_cmd("make", ["-C", dir])
        # Якщо ми root, спробуємо також make install
        if SystemUtils.running_as_root?(), do: _ = SystemUtils.run_cmd("make", ["-C", dir, "install"])
    end

    # 4) Немає специфічних для додатків евристик
  end

  # Рекурсивний пошук файлів до вказаної глибини
  defp recurse_files(dir, depth) when depth >= 0 do
    case File.ls(dir) do
      {:ok, entries} ->
        Enum.flat_map(entries, fn name ->
          path = Path.join(dir, name)
          case File.stat(path) do
            {:ok, %File.Stat{type: :directory}} ->
              # Якщо це директорія, додаємо її та рекурсивно шукаємо в ній
              [path | recurse_files(path, depth - 1)]
            {:ok, _} -> [path]  # Якщо це файл, просто додаємо його
            _ -> []  # Якщо помилка, ігноруємо
          end
        end)
      _ -> []  # Якщо не можемо прочитати директорію
    end
  end

  # Базовий випадок рекурсії - коли глибина вичерпана
  defp recurse_files(_dir, _depth), do: []


end