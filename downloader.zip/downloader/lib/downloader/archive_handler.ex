defmodule Downloader.ArchiveHandler do
  @moduledoc """
  Обробляє розпакування різних форматів архівів.
  """

  alias Downloader.PostInstall

  # Розпакування архіву за допомогою вказаної програми
  def unpack_archive(archive_path, program, args_before_archive) do
    dir = Path.dirname(archive_path)
    cmd_args = build_unpack_args(program, args_before_archive, archive_path, dir)
    IO.puts "Спроба розпакувати '#{archive_path}' використовуючи '#{program} #{Enum.join(cmd_args, " ")}'..."

    case System.cmd(program, cmd_args, stderr_to_stdout: true) do
      {output, 0} ->
        IO.puts "Архів успішно розпаковано."
        IO.puts "Вивід: \n#{output}"
        extracted_dir = dir
        IO.puts "Пошук скриптів установки в #{extracted_dir}..."
        PostInstall.inspect_directory(extracted_dir)
        PostInstall.automate_post_unpack(extracted_dir)
        {:ok, :unpacked}

      {output, exit_code} ->
        IO.puts "Помилка розпакування архіву. Код виходу: #{exit_code}"
        IO.puts "Вивід помилки: \n#{output}"
        {:error, :unpack_failed}
    end
  end

  # Декомпресія одиночного файлу
  def decompress_single_file(file_path, program, args_before_file) do
    dir = Path.dirname(file_path)
    IO.puts "Спроба декомпресії '#{file_path}' використовуючи '#{program} #{Enum.join(args_before_file ++ [file_path], " ")}'..."
    case System.cmd(program, args_before_file ++ [file_path], stderr_to_stdout: true) do
      {output, 0} ->
        IO.puts output
        IO.puts "Успішно декомпресовано в #{dir}"
        PostInstall.automate_post_unpack(dir)
        {:ok, :decompressed}
      {output, status} ->
        IO.puts output
        {:error, {:decompress_failed, status}}
    end
  end

  # Побудова аргументів для tar
  defp build_unpack_args("tar", args_before_archive, archive_path, dir) do
    # tar ... archive -C dir
    args_before_archive ++ [archive_path, "-C", dir]
  end

  # Побудова аргументів для unzip
  defp build_unpack_args("unzip", args_before_archive, archive_path, dir) do
    # unzip -o archive -d dir (перезаписати без запиту)
    args_before_archive ++ ["-o", archive_path, "-d", dir]
  end

  # Побудова аргументів для unrar
  defp build_unpack_args("unrar", args_before_archive, archive_path, dir) do
    # unrar x -o+ archive dir (перезаписати без запиту)
    args_before_archive ++ ["-o+", archive_path, dir]
  end

  # Побудова аргументів для 7z
  defp build_unpack_args("7z", args_before_archive, archive_path, dir) do
    # 7z x -y archive -oDIR (відповісти "Так" на все)
    args_before_archive ++ ["-y", archive_path, "-o" <> dir]
  end

  # Резервний варіант для інших програм
  defp build_unpack_args(_program, args_before_archive, archive_path, _dir) do
    # Резервний варіант
    args_before_archive ++ [archive_path]
  end
end