defmodule Downloader.PackageHandler do
  @moduledoc """
  Обробляє установку та розпакування різних форматів пакетів.
  """

  alias Downloader.SystemUtils

  # Головна функція обробки пакетів
  def handle_package(archive_path, ext) do
    case ext do
      ".deb" -> install_deb(archive_path)           # Debian пакети
      ".rpm" -> install_rpm(archive_path)           # RPM пакети
      ".appimage" -> unpack_appimage(archive_path)  # AppImage файли
      ".snap" -> install_snap(archive_path)         # Snap пакети
      ".flatpak" -> install_flatpak(archive_path)   # Flatpak пакети
      ".flatpakref" -> unpack_flatpakref(archive_path) # Flatpak посилання
      ".pkg.tar.zst" -> unpack_pacman_pkg(archive_path) # Pacman пакети
      ".apk" -> unpack_apk_pkg(archive_path)        # Alpine пакети
      ".run" -> unpack_run_bin(archive_path)        # Самовитягувальні файли
      ".bin" -> unpack_run_bin(archive_path)        # Бінарні установники
      _ -> {:error, :unsupported_package_type}
    end
  end

  # ----- Методи установки пакетів -----
  # Установка .deb пакетів (Debian/Ubuntu)
  defp install_deb(path) do
    cond do
      # Перевіряємо, чи це Debian-подібна система
      not SystemUtils.debian_like?() ->
        IO.puts("⚠ .deb пакети не підтримуються на цьому дистрибутиві")
        IO.puts("  Схоже, це не Debian-подібна система")
        IO.puts("  Ви можете спробувати розпакувати .deb вручну або використати інший формат пакету")
        {:error, :unsupported_on_distro}

      # Перевіряємо наявність dpkg
      not SystemUtils.command_available?("dpkg") ->
        IO.puts("❌ dpkg недоступний на цій системі")
        IO.puts("  Будь ласка, встановіть dpkg або використайте інший формат пакету")
        {:error, :missing_tool}

      true ->
        IO.puts("Установка .deb пакету...")
        case SystemUtils.maybe_with_sudo("dpkg", ["-i", path]) do
          {:ok, _} ->
            # Спробуємо виправити залежності якщо доступний apt-get
            if SystemUtils.command_available?("apt-get") do
              IO.puts("Виправлення залежностей за допомогою apt-get...")
              _ = SystemUtils.maybe_with_sudo("apt-get", ["-f", "install", "-y"]) 
            end
            {:ok, :installed}
          {:error, _} -> {:error, :install_failed}
        end
    end
  end

  # Установка .rpm пакетів (Red Hat/Fedora/SUSE)
  defp install_rpm(path) do
    cond do
      # Перевіряємо, чи це RPM-подібна система
      not (SystemUtils.rhel_like?() or SystemUtils.suse_like?()) ->
        IO.puts("⚠ .rpm пакети не підтримуються на цьому дистрибутиві")
        IO.puts("  Схоже, це не RPM-подібна система")
        IO.puts("  Ви можете спробувати розпакувати .rpm вручну або використати інший формат пакету")
        {:error, :unsupported_on_distro}

      true ->
        IO.puts("Установка .rpm пакету...")
        cond do
          # Спробуємо dnf (сучасний Fedora/RHEL)
          SystemUtils.command_available?("dnf") -> 
            IO.puts("Використання менеджера пакетів dnf...")
            SystemUtils.maybe_with_sudo("dnf", ["-y", "install", path])
          # Спробуємо yum (старіший RHEL/CentOS)
          SystemUtils.command_available?("yum") -> 
            IO.puts("Використання менеджера пакетів yum...")
            SystemUtils.maybe_with_sudo("yum", ["-y", "localinstall", path])
          # Спробуємо zypper (openSUSE)
          SystemUtils.command_available?("zypper") -> 
            IO.puts("Використання менеджера пакетів zypper...")
            SystemUtils.maybe_with_sudo("zypper", ["--non-interactive", "install", path])
          # Спробуємо rpm напряму
          SystemUtils.command_available?("rpm") -> 
            IO.puts("Використання rpm напряму...")
            SystemUtils.maybe_with_sudo("rpm", ["-i", path])
          true ->
            IO.puts("❌ Не знайдено RPM-сумісного установника (dnf/yum/zypper/rpm)")
            IO.puts("  Будь ласка, встановіть менеджер пакетів або використайте інший формат пакету")
            {:error, :missing_tool}
        end
    end
  end

  # Установка .snap пакетів
  defp install_snap(path) do
    cond do
      not SystemUtils.command_available?("snap") ->
        IO.puts("❌ snap недоступний на цій системі")
        IO.puts("  Будь ласка, встановіть snapd для установки .snap пакетів")
        {:error, :missing_tool}
      true ->
        IO.puts("Установка .snap пакету...")
        SystemUtils.maybe_with_sudo("snap", ["install", "--dangerous", path])
    end
  end

  # Установка .flatpak пакетів
  defp install_flatpak(path) do
    cond do
      not SystemUtils.command_available?("flatpak") ->
        IO.puts("❌ flatpak недоступний на цій системі")
        IO.puts("  Будь ласка, встановіть flatpak для установки .flatpak пакетів")
        {:error, :missing_tool}
      true ->
        IO.puts("Установка .flatpak пакету...")
        SystemUtils.run_cmd("flatpak", ["install", "--user", "-y", path])
    end
  end



  # Розпакування AppImage файлів
  defp unpack_appimage(path) do
    abs = Path.expand(path)
    dir = Path.dirname(abs)
    target = Path.join(dir, "squashfs-root")
    # Видаляємо попередню директорію якщо існує
    _ = File.rm_rf(target)
    # Робимо файл виконуваним
    _ = File.chmod(abs, 0o755)
    # Витягуємо вміст AppImage
    case System.cmd(abs, ["--appimage-extract"], cd: dir, stderr_to_stdout: true) do
      {output, 0} -> IO.puts(output); {:ok, 0}
      {output, status} -> IO.puts(output); {:error, status}
    end
  end



  # Обробка .flatpakref файлів (це текстові посилання)
  defp unpack_flatpakref(path) do
    IO.puts(".flatpakref це файл посилання (текст). Розпакування не виконується. Збережено в: #{path}")
    {:ok, :reference}
  end

  # Розпакування пакетів Pacman (.pkg.tar.zst)
  defp unpack_pacman_pkg(path) do
    # Це tar.zst; вже обробляється tar.zst, але залишаємо явно для ясності
    case SystemUtils.check_dependencies(["tar"]) do
      {:ok, "tar"} -> 
        Downloader.ArchiveHandler.unpack_archive(path, "tar", ["--zstd", "-xf"])
      {:error, _} -> {:error, :missing_dependencies}
    end
  end

  # Розпакування пакетів Alpine (.apk)
  defp unpack_apk_pkg(path) do
    # Alpine .apk це tar.gz
    case SystemUtils.check_dependencies(["tar"]) do
      {:ok, "tar"} -> 
        Downloader.ArchiveHandler.unpack_archive(path, "tar", ["-xzf"])
      {:error, _} -> {:error, :missing_dependencies}
    end
  end

  # Розпакування .run/.bin файлів (самовитягувальні установники)
  defp unpack_run_bin(path) do
    # Спробуємо загальні прапори витягування; резервний варіант - bsdtar
    dir = Path.dirname(path)
    abs = Path.expand(path)
    out = Path.join(dir, Path.basename(path) <> "-contents")
    _ = File.mkdir_p(out)
    _ = File.chmod(abs, 0o755)
    # Кандидати для спроби витягування
    candidates = [
      {abs, ["--noexec", "--target", out]},
      {abs, ["--extract", "--target", out]}
    ]
    case Enum.find_value(candidates, fn {prog, argv} ->
      case System.cmd(prog, argv, stderr_to_stdout: true) do
        {output, 0} -> IO.puts(output); {:ok, 0}
        _ -> false
      end
    end) do
      {:ok, 0} -> {:ok, 0}
      _ ->
        # Резервний варіант - використовуємо bsdtar
        if SystemUtils.command_available?("bsdtar") do
          IO.puts("Витягування .run/.bin використовуючи bsdtar...")
          SystemUtils.run_cmd("bsdtar", ["-xf", path, "-C", out])
        else
          IO.puts("❌ Не вдалося витягнути .run/.bin (потрібні сумісні прапори або bsdtar)")
          IO.puts("  Будь ласка, встановіть bsdtar для витягування .run/.bin файлів")
          {:error, :missing_tool}
        end
    end
  end


end