defmodule Downloader.SystemUtils do
  @moduledoc """
  Системні утиліти для перевірки залежностей, виконання команд та обробки привілеїв.
  """

  # Перевірка, чи працюємо під root
  def running_as_root?() do
    case System.cmd("id", ["-u"]) do
      {"0\n", 0} -> true  # UID 0 = root
      {"0", 0} -> true
      _ -> false
    end
  end

  # Перевірка доступності команди в системі
  def command_available?(cmd) when is_binary(cmd) do
    System.find_executable(cmd) != nil
  end

  # Перевірка, чи доступні будь-які з необхідних інструментів
  def check_dependencies(required_tools) when is_list(required_tools) do
    available_tools = Enum.filter(required_tools, &command_available?/1)
    case available_tools do
      [tool | _] -> {:ok, tool}
      [] -> {:error, required_tools}
    end
  end

  # Перевірка можливостей системи та надання корисних повідомлень
  def check_system_capabilities() do
    IO.puts "=== Перевірка можливостей системи ==="

    # Перевірка базових інструментів для архівів
    basic_tools = ["tar", "unzip", "gunzip", "unxz", "bunzip2"]
    missing_basic = Enum.reject(basic_tools, &command_available?/1)

    if missing_basic == [] do
      IO.puts "✓ Базові інструменти для архівів доступні"
    else
      IO.puts "⚠ Відсутні базові інструменти: #{Enum.join(missing_basic, ", ")}"
      IO.puts "  Зазвичай вони попередньо встановлені на більшості Linux систем"
    end

    # Перевірка розширених інструментів
    advanced_tools = ["7z", "unrar", "zstd"]
    available_advanced = Enum.filter(advanced_tools, &command_available?/1)

    if available_advanced == [] do
      IO.puts "⚠ Розширені інструменти для архівів не знайдені (7z, unrar, zstd)"
      IO.puts "  Деякі формати архівів можуть не підтримуватися"
    else
      IO.puts "✓ Розширені інструменти доступні: #{Enum.join(available_advanced, ", ")}"
    end

    # Перевірка менеджерів пакетів
    package_managers = ["dpkg", "rpm", "snap", "flatpak"]
    available_pkg_mgrs = Enum.filter(package_managers, &command_available?/1)

    if available_pkg_mgrs == [] do
      IO.puts "⚠ Менеджери пакетів не знайдені"
      IO.puts "  Установка пакетів буде недоступна"
    else
      IO.puts "✓ Менеджери пакетів доступні: #{Enum.join(available_pkg_mgrs, ", ")}"
    end

    # Перевірка підвищення привілеїв
    if command_available?("sudo") or command_available?("pkexec") do
      IO.puts "✓ Підвищення привілеїв доступне"
    else
      IO.puts "⚠ Інструменти підвищення привілеїв не знайдені"
      IO.puts "  Установка пакетів може не працювати"
    end

    IO.puts "=================================="
  end

  def os_release() do
    with {:ok, content} <- File.read("/etc/os-release") do
      content
      |> String.split("\n", trim: true)
      |> Enum.reduce(%{}, fn line, acc ->
        case String.split(line, "=", parts: 2) do
          [k, v] -> Map.put(acc, k, String.trim(v, "\""))
          _ -> acc
        end
      end)
    else
      _ -> %{}
    end
  end

  def distro_like?(like) do
    info = os_release()
    id = Map.get(info, "ID", "")
    id_like = Map.get(info, "ID_LIKE", "")
    String.contains?(id, like) or String.contains?(id_like, like)
  end

  # Функції для визначення типу дистрибутива
  def debian_like?(), do: distro_like?("debian") or distro_like?("ubuntu")
  def rhel_like?(), do: distro_like?("rhel") or distro_like?("fedora") or distro_like?("centos")
  def suse_like?(), do: distro_like?("suse")
  def arch_like?(), do: distro_like?("arch")

  # Виконання команди з виводом результату
  def run_cmd(program, args) do
    case System.cmd(program, args, stderr_to_stdout: true) do
      {output, 0} ->
        IO.puts(output)
        {:ok, 0}
      {output, status} ->
        IO.puts(output)
        {:error, status}
    end
  end

  # Виконання команди з можливим використанням sudo
  def maybe_with_sudo(program, args) do
    if running_as_root?() do
      # Якщо вже root - виконуємо напряму
      run_cmd(program, args)
    else
      if command_available?("sudo") do
        prog = to_string(program)
        argv = Enum.map(args, &to_string/1)

        # 1) Віддаємо перевагу pkexec для нативної GUI аутентифікації якщо доступно
        has_display = System.get_env("DISPLAY") not in [nil, ""]
        if has_display and command_available?("pkexec") do
          case System.cmd("pkexec", [prog | argv], stderr_to_stdout: true) do
            {output, 0} -> IO.puts(output); {:ok, 0}
            {output, status} -> IO.puts(output); {:error, status}
          end
        else
          # 2) Спробуємо GUI-збір паролю з sudo -S
          case prompt_password() do
            {:ok, password} ->
              cmd = ["printf '%s\\n' \"$PW\" | sudo -S ", shell_escape(prog),
                     (if argv == [], do: "", else: " " <> (Enum.map(argv, &shell_escape/1) |> Enum.join(" ")))]
                    |> Enum.join()
              case System.cmd("sh", ["-c", cmd], stderr_to_stdout: true, env: [{"PW", password}]) do
                {output, 0} -> IO.puts(output); {:ok, 0}
                {output, status} -> IO.puts(output); {:error, status}
              end
            :no_gui ->
              # 3) Резервний варіант - TTY sudo запит
              case System.cmd("sudo", [prog | argv], stderr_to_stdout: true) do
                {output, 0} -> IO.puts(output); {:ok, 0}
                {output, status} -> IO.puts(output); {:error, status}
              end
          end
        end
      else
        IO.puts("sudo недоступний для підвищення привілеїв")
        {:error, :no_sudo}
      end
    end
  end

  # Екранування рядка для безпечного використання в shell
  defp shell_escape(str) when is_binary(str) do
    "'" <> String.replace(str, "'", "'\\''") <> "'"
  end

  # Запит паролю через GUI діалог
  defp prompt_password do
    has_display = System.get_env("DISPLAY") not in [nil, ""]
    cond do
      not has_display -> :no_gui
      # Спробуємо zenity (GNOME)
      System.find_executable("zenity") ->
        case System.cmd("zenity", ["--password", "--title=Потрібна аутентифікація"], stderr_to_stdout: true) do
          {pwd, 0} -> {:ok, trim_last_line(pwd)}
          _ -> :no_gui
        end
      # Спробуємо kdialog (KDE)
      System.find_executable("kdialog") ->
        case System.cmd("kdialog", ["--password", "Потрібна аутентифікація"], stderr_to_stdout: true) do
          {pwd, 0} -> {:ok, trim_last_line(pwd)}
          _ -> :no_gui
        end
      # Спробуємо yad (універсальний)
      System.find_executable("yad") ->
        case System.cmd("yad", ["--entry", "--hide-text", "--title=Потрібна аутентифікація", "--text=Введіть пароль"], stderr_to_stdout: true) do
          {pwd, 0} -> {:ok, trim_last_line(pwd)}
          _ -> :no_gui
        end
      true -> :no_gui
    end
  end

  # Обрізання останнього рядка з вивосутніх інструментів
  def show_install_commands(missing_tools) when is_list(missing_tools) do
    IO.puts("📦 Для встановлення відсутніх інструментів використайте:")
    IO.puts("")

    for tool <- missing_tools do
      show_install_command_for_tool(tool)
    end
  end

  # Показ команди встановлення для конкретного інструменту
  defp show_install_command_for_tool(tool) do
    IO.puts("🔧 Для встановлення #{tool}:")

    cond do
      debian_like?() ->
        package = get_debian_package(tool)
        IO.puts("   sudo apt update && sudo apt install #{package}")

      rhel_like?() ->
        package = get_rhel_package(tool)
        if command_available?("dnf") do
          IO.puts("   sudo dnf install #{package}")
        else
          IO.puts("   sudo yum install #{package}")
        end

      suse_like?() ->
        package = get_suse_package(tool)
        IO.puts("   sudo zypper install #{package}")

      arch_like?() ->
        package = get_arch_package(tool)
        IO.puts("   sudo pacman -S #{package}")

      true ->
        IO.puts("   Встановіть #{tool} через менеджер пакетів вашого дистрибутива")
    end

    IO.puts("")
  end

  # Мапінг інструментів до пакетів для Debian/Ubuntu
  defp get_debian_package(tool) do
    case tool do
      "tar" -> "tar"
      "unzip" -> "unzip"
      "gunzip" -> "gzip"
      "gzip" -> "gzip"
      "unxz" -> "xz-utils"
      "xz" -> "xz-utils"
      "bunzip2" -> "bzip2"
      "bzip2" -> "bzip2"
      "unzstd" -> "zstd"
      "zstd" -> "zstd"
      "7z" -> "p7zip-full"
      "p7zip" -> "p7zip-full"
      "unrar" -> "unrar"
      "rar" -> "rar"
      "dpkg" -> "dpkg"
      "rpm" -> "rpm"
      "snap" -> "snapd"
      "flatpak" -> "flatpak"
      "curl" -> "curl"
      "wget" -> "wget"
      "make" -> "build-essential"
      "gcc" -> "build-essential"
      "python3" -> "python3"
      "pip" -> "python3-pip"
      "git" -> "git"
      _ -> tool
    end
  end

  # Мапінг інструментів до пакетів для RHEL/Fedora/CentOS
  defp get_rhel_package(tool) do
    case tool do
      "tar" -> "tar"
      "unzip" -> "unzip"
      "gunzip" -> "gzip"
      "gzip" -> "gzip"
      "unxz" -> "xz"
      "xz" -> "xz"
      "bunzip2" -> "bzip2"
      "bzip2" -> "bzip2"
      "unzstd" -> "zstd"
      "zstd" -> "zstd"
      "7z" -> "p7zip p7zip-plugins"
      "p7zip" -> "p7zip p7zip-plugins"
      "unrar" -> "unrar"
      "rar" -> "rar"
      "dpkg" -> "dpkg"
      "rpm" -> "rpm"
      "snap" -> "snapd"
      "flatpak" -> "flatpak"
      "curl" -> "curl"
      "wget" -> "wget"
      "make" -> "make gcc"
      "gcc" -> "gcc"
      "python3" -> "python3"
      "pip" -> "python3-pip"
      "git" -> "git"
      _ -> tool
    end
  end

  # Мапінг інструментів до пакетів для openSUSE
  defp get_suse_package(tool) do
    case tool do
      "tar" -> "tar"
      "unzip" -> "unzip"
      "gunzip" -> "gzip"
      "gzip" -> "gzip"
      "unxz" -> "xz"
      "xz" -> "xz"
      "bunzip2" -> "bzip2"
      "bzip2" -> "bzip2"
      "unzstd" -> "zstd"
      "zstd" -> "zstd"
      "7z" -> "p7zip"
      "p7zip" -> "p7zip"
      "unrar" -> "unrar"
      "rar" -> "rar"
      "dpkg" -> "dpkg"
      "rpm" -> "rpm"
      "snap" -> "snapd"
      "flatpak" -> "flatpak"
      "curl" -> "curl"
      "wget" -> "wget"
      "make" -> "make gcc"
      "gcc" -> "gcc"
      "python3" -> "python3"
      "pip" -> "python3-pip"
      "git" -> "git"
      _ -> tool
    end
  end

  # Мапінг інструментів до пакетів для Arch Linux
  defp get_arch_package(tool) do
    case tool do
      "tar" -> "tar"
      "unzip" -> "unzip"
      "gunzip" -> "gzip"
      "gzip" -> "gzip"
      "unxz" -> "xz"
      "xz" -> "xz"
      "bunzip2" -> "bzip2"
      "bzip2" -> "bzip2"
      "unzstd" -> "zstd"
      "zstd" -> "zstd"
      "7z" -> "p7zip"
      "p7zip" -> "p7zip"
      "unrar" -> "unrar"
      "rar" -> "rar"
      "dpkg" -> "dpkg"
      "rpm" -> "rpm-tools"
      "snap" -> "snapd"
      "flatpak" -> "flatpak"
      "curl" -> "curl"
      "wget" -> "wget"
      "make" -> "base-devel"
      "gcc" -> "base-devel"
      "python3" -> "python"
      "pip" -> "python-pip"
      "git" -> "git"
      _ -> tool
    end
  end

  # Обрізання останнього рядка з виводу
  defp trim_last_line(output) do
    output
    |> String.split("\n")
    |> Enum.map(&String.trim/1)
    |> Enum.reject(&(&1 == ""))
    |> List.last()
    |> (fn x -> x || "" end).()
  end
end
