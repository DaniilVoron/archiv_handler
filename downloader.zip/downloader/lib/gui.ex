defmodule Downloader.GUI do
  @moduledoc """
  Simple GUI wrapper around `LinuxInstaller` using common file chooser tools
  available on Linux desktops: `zenity`, `kdialog`, or `yad`.
  """

  def pick_and_install do
    case pick_file() do
      {:ok, path} ->
        LinuxInstaller.install(path)
      {:error, reason} ->
        IO.puts("GUI error: #{inspect(reason)}")
        {:error, reason}
    end
  end

  defp pick_file do
    cond do
      System.find_executable("zenity") -> zenity_file_chooser()
      System.find_executable("kdialog") -> kdialog_file_chooser()
      System.find_executable("yad") -> yad_file_chooser()
      true -> {:error, :no_gui_tools}
    end
  end

  defp zenity_file_chooser do
    args = ["--file-selection", "--title=Select archive or package"]
    case System.cmd("zenity", args, stderr_to_stdout: true) do
      {output, 0} -> parse_picker_output(output)
      {output, _} -> {:error, {:zenity_failed, output}}
    end
  end

  defp kdialog_file_chooser do
    args = ["--getopenfilename", ".", "*.*|All files"]
    case System.cmd("kdialog", args, stderr_to_stdout: true) do
      {output, 0} -> parse_picker_output(output)
      {output, _} -> {:error, {:kdialog_failed, output}}
    end
  end

  defp yad_file_chooser do
    args = ["--file", "--title=Select archive or package"]
    case System.cmd("yad", args, stderr_to_stdout: true) do
      {output, 0} -> parse_picker_output(output)
      {output, _} -> {:error, {:yad_failed, output}}
    end
  end

  defp parse_picker_output(output) when is_binary(output) do
    output
    |> String.split("\n")
    |> Enum.map(&String.trim/1)
    |> Enum.reject(&(&1 == ""))
    |> Enum.reverse()
    |> Enum.find(fn line -> String.starts_with?(line, "/") and File.exists?(line) end)
    |> case do
      nil -> {:error, :no_valid_path_found}
      path -> {:ok, path}
    end
  end
end


