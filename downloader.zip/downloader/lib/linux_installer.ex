defmodule LinuxInstaller do
  @moduledoc """
  Базова утиліта Elixir для допомоги в установці програм з архівів на Linux.
  Може ідентифікувати типи архівів та розпаковувати їх з повною автономією та перевіркою залежностей.
  """

  alias Downloader.{ArchiveHandler, PackageHandler, SystemUtils, PostInstall}

  # Мапа розширень архівів (в нижньому регістрі) до {програма, аргументи_перед_архівом, необхідні_інструменти}
  @supported_archive_types %{
    ".tar" => {"tar", ["-xf"], ["tar"]},
    ".tar.gz" => {"tar", ["-xzf"], ["tar"]},
    ".tgz" => {"tar", ["-xzf"], ["tar"]},
    ".tar.xz" => {"tar", ["-xJf"], ["tar"]},
    ".txz" => {"tar", ["-xJf"], ["tar"]},
    ".tar.bz2" => {"tar", ["-xjf"], ["tar"]},
    ".tbz2" => {"tar", ["-xjf"], ["tar"]},
    ".tar.zst" => {"tar", ["--zstd", "-xf"], ["tar"]},
    ".tzst" => {"tar", ["--zstd", "-xf"], ["tar"]},
    ".zip" => {"unzip", [], ["unzip"]},
    ".rar" => {"unrar", ["x"], ["unrar", "rar"]},
    ".7z" => {"7z", ["x"], ["7z", "p7zip"]}
  }

  # Формати стиснення одиночних файлів (розпакування в ту ж директорію)
  @single_file_compressions %{
    ".gz" => {"gunzip", [], ["gunzip", "gzip"]},
    ".xz" => {"unxz", [], ["unxz", "xz"]},
    ".bz2" => {"bunzip2", [], ["bunzip2", "bzip2"]},
    ".zst" => {"unzstd", [], ["unzstd", "zstd"]}
  }

  @package_types [
    ".deb",
    ".rpm",
    ".appimage",
    ".snap",
    ".flatpak",
    ".flatpakref",
    ".pkg.tar.zst",
    ".apk",
    ".run",
    ".bin"
  ]

  @doc """
  Спроба установки з наданого `archive_path`.
  """
  def install(archive_path) when is_binary(archive_path) do
    # Розв'язуємо джерело (локальний файл або URL)
    case resolve_source(archive_path) do
      {:ok, local_path} -> do_install(local_path)
      {:error, reason} ->
        IO.puts "Помилка: Архів не знайдено за адресою '#{archive_path}'"
        {:error, reason}
    end
  end

  # Приватна функція для виконання установки
  defp do_install(archive_path) do
    # Визначаємо розширення файлу
    ext = detect_extension(archive_path)

    cond do
      # Перевіряємо, чи це підтримуваний тип архіву
      is_map_key(@supported_archive_types, ext) ->
        IO.puts "Ідентифіковано тип архіву: #{ext}"
        {_program, args, required_tools} = Map.fetch!(@supported_archive_types, ext)
        # Перевіряємо наявність необхідних інструментів
        case SystemUtils.check_dependencies(required_tools) do
          {:ok, available_program} ->
            ArchiveHandler.unpack_archive(archive_path, available_program, args)
          {:error, missing} ->
            IO.puts "Помилка: Не знайдено необхідні інструменти: #{Enum.join(missing, ", ")}"
            IO.puts "Будь ласка, встановіть відсутні інструменти та спробуйте знову."
            {:error, :missing_dependencies}
        end

      # Перевіряємо, чи це стиснений файл
      is_map_key(@single_file_compressions, ext) ->
        IO.puts "Ідентифіковано стиснений файл: #{ext}"
        {_program, args, required_tools} = Map.fetch!(@single_file_compressions, ext)
        case SystemUtils.check_dependencies(required_tools) do
          {:ok, available_program} ->
            ArchiveHandler.decompress_single_file(archive_path, available_program, args)
          {:error, missing} ->
            IO.puts "Помилка: Не знайдено необхідні інструменти: #{Enum.join(missing, ", ")}"
            IO.puts "Будь ласка, встановіть відсутні інструменти та спробуйте знову."
            {:error, :missing_dependencies}
        end

      # Перевіряємо, чи це пакет
      ext in @package_types ->
        PackageHandler.handle_package(archive_path, ext)

      # Невідомий тип файлу
      true ->
        IO.puts "Непідтримуваний або невідомий тип архіву: #{Path.extname(archive_path)}"
        IO.puts "Спроба переглянути вміст директорії архіву для пошуку скрипта установки..."
        PostInstall.inspect_directory(Path.dirname(archive_path))
        {:error, :unsupported_type}
    end
  end

  # Визначення складених розширень як .tar.gz шляхом зіставлення з відомими суфіксами
  defp detect_extension(path) do
    downcased = String.downcase(path)

    @supported_archive_types
    |> Map.keys()
    |> Enum.concat(@package_types)
    |> Enum.sort_by(&String.length/1, :desc)
    |> Enum.find(fn suffix -> String.ends_with?(downcased, suffix) end)
    |> case do
      nil -> String.downcase(Path.extname(path))
      suffix -> suffix
    end
  end

  # ----- Розв'язання джерела (локальний шлях або завантаження URL) -----
  defp resolve_source(path) when is_binary(path) do
    trimmed = String.trim(path)
    if url?(trimmed) do
      # Якщо це URL - завантажуємо до директорії Завантажене
      download_to_tmp(trimmed)
    else
      # Якщо це локальний файл - перевіряємо його існування
      if File.exists?(trimmed) do
        {:ok, trimmed}
      else
        {:error, :file_not_found}
      end
    end
  end

  # Перевірка, чи є шлях URL
  defp url?(path) do
    String.starts_with?(path, ["http://", "https://"])
  end

  # Завантаження файлу з URL до директорії Завантажене
  defp download_to_tmp(url) do
    # Отримуємо домашню директорію користувача
    home_dir = System.user_home!()
    downloads_dir = Path.join(home_dir, "Завантажене")

    # Створюємо директорію Завантажене якщо вона не існує
    File.mkdir_p(downloads_dir)

    filename = url_filename(url)
    target = Path.join(downloads_dir, filename)

    cond do
      # Використовуємо curl якщо доступний
      SystemUtils.command_available?("curl") ->
        IO.puts("Завантаження через curl: #{url}")
        case System.cmd("curl", ["-L", "-o", target, url], stderr_to_stdout: true) do
          {_, 0} -> {:ok, target}
          {out, status} -> IO.puts(out); {:error, {:download_failed, status}}
        end

      # Використовуємо вбудований HTTP клієнт Erlang
      true ->
        :inets.start()
        :ssl.start()
        case :httpc.request(:get, {String.to_charlist(url), []}, [], body_format: :binary) do
          {:ok, {{_, 200, _}, _headers, body}} ->
            case File.write(target, body) do
              :ok -> {:ok, target}
              {:error, reason} -> {:error, reason}
            end
          {:ok, {{_, code, _}, _headers, _}} -> {:error, {:http_error, code}}
          {:error, reason} -> {:error, reason}
        end
    end
  end

  # Отримання імені файлу з URL
  defp url_filename(url) do
    uri = URI.parse(url)
    base = (uri.path || "/") |> Path.basename()
    if base == "" or base == "/" do
      # Генеруємо унікальне ім'я якщо не можемо визначити з URL
      "download-" <> Integer.to_string(:erlang.unique_integer([:positive]))
    else
      base
    end
  end

  @doc """
  Точка входу CLI з підтримкою різних команд.
  """
  def main(args \\ []) do
    args = if args == [], do: System.argv(), else: args

    case args do
      ["--help"] ->
        show_help()

      ["--check"] ->
        check_system_capabilities()

      ["--gui"] ->
        Downloader.GUI.pick_and_install()

      [url_or_path] ->
        install(url_or_path)

      [url_or_path, target_dir] ->
        File.cd!(target_dir)
        install(url_or_path)

      _ ->
        IO.puts("Невірні аргументи. Використовуйте --help для довідки.")
        System.halt(1)
    end
  end

  defp show_help do
    IO.puts """
    Використання: dl [ОПЦІЇ] [URL/ШЛЯХ] [ДИРЕКТОРІЯ]

    Опції:
      --help      Показати цю довідку
      --check     Перевірити системні можливості
      --gui       Запустити графічний інтерфейс вибору файлу

    Приклади:
      dl --gui
      dl https://example.com/archive.tar.gz
      dl /home/user/file.zip
      dl https://example.com/app.tar.gz /opt/apps
    """
  end

  # Перевірка можливостей системи та надання корисних повідомлень
  def check_system_capabilities() do
    SystemUtils.check_system_capabilities()
  end
end
